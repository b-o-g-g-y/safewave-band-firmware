package com.example.bluetooth.le;

import android.widget.ImageView;
import android.widget.TextView;

public class MyFile {
	public ImageView mFileImageView;  //文件图片
	public TextView mFileNameTV;    //文件�?
}
